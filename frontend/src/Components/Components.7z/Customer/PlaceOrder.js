import { FormControl } from "baseui/form-control";
import { Select } from "baseui/select";
import React, { useState, useEffect } from "react";
import { Col, Row } from "react-bootstrap";
import axiosConfig from "../../axiosConfig";
import CustomerNavbar from "./CustomerNavbar";
import { useHistory, match } from "react-router";
import { H4 } from "baseui/typography";
import { Button, KIND } from "baseui/button";
import logo from "../../assets/images/ubereats.png";
import { Drawer } from "baseui/drawer";
import { Menu } from "baseui/menu";
import { ALIGN, HeaderNavigation,   StyledNavigationList as NavigationList,
} from "baseui/header-navigation";


function PlaceOrder({ match }) {
  const [addresses, setAddresses] = useState([]);
  const [orderDetails, setOrderDetails] = useState({});
  const history = useHistory();

  const getAddresses = () => {
    const token = localStorage.getItem("token");
    axiosConfig
      .get("/customers/address", {
        headers: {
          Authorization: token,
        },
      })
      .then((res) => {
        setAddresses(res.data);
      })
      .catch((err) => {
        console.log(err.response.data);
      });
  };

  const getOrderDetails = () => {
    const token = localStorage.getItem("token");
    axiosConfig
      .get(`/orders/${match.params.oid}`, {
        headers: {
          Authorization: token,
        },
      })
      .then((res) => {
        setOrderDetails(res.data);
      })
      .catch((err) => {
        console.log(err.response.data);
      });
  };

  console.log(orderDetails);
  useEffect(() => {
    getAddresses();
    getOrderDetails();
  }, []);
  console.log(orderDetails);

  return (
    <div>
      <HeaderNavigation style={{ height: "90px" }}>
      <NavigationList $align={ALIGN.left}>
        <Button kind={KIND.minimal} onClick={() => setIsDrawerOpen(true)}>
          <Menu />
        </Button>
        <Drawer
          isOpen={isDrawerOpen}
          autoFocus
          anchor={ANCHOR.left}
          onClose={() => setIsDrawerOpen(false)}
        >
          <div style={{ marginTop: "10%" }}>
            <div style={{ marginTop: "5%" }}>
              <Button
                style={{ width: "100%" }}
                onClick={() => history.push("/customer/update")}
              >
                Update Profile
              </Button>
            </div>
            <div style={{ marginTop: "5%" }}>
              <Button style={{ width: "100%" }}> Past Orders </Button>
            </div>
            <div style={{ marginTop: "5%" }}>
              <Button style={{ width: "100%" }}> Favorites </Button>
            </div>
          </div>
        </Drawer>
        <NavigationItem>
          <a href="/customer/dashboard">
            <img src={logo} style={{ width: "100px", height: "70px" }} />
          </a>
        </NavigationItem>
      </NavigationList>
      </HeaderNavigation>
      <Row>
        <Col style={{alignItems:"left", paddingLeft:"50px"}}>
            <H4>{orderDetails?.restaurant?.r_name}</H4>
            <img
              src={
                orderDetails?.restaurant?.restaurant_imgs?.length > 0
                  ? orderDetails?.restaurant?.restaurant_imgs[0]?.ri_img
                  : ""
              }
              style={{ height:"300px", width:"700px"}}
            />
            <form style={{ width: "50%" }}>
              <FormControl label="Select Delivery Address">
                <Select
                  options={[
                    { address: "San Jose" },
                    { address: "San Francisco" },
                    { address: "New York" },
                    { address: "Santa Clara" },
                  ]}
                  valueKey="address"
                  labelKey="address"
                  placeholder="Select address"
                />
              </FormControl>
              <FormControl label="Select Delivery Type">
                <Select
                  options={[
                    { deliveryType: "Delivery" },
                    { deliveryType: "Pickup" },
                  ]}
                  valueKey="deliveryType"
                  labelKey="deliveryType"
                  placeholder="Select delivery Type"
                />
              </FormControl>
            </form>
        </Col>
        <Col>
          <p>Total Price: {orderDetails.o_total_price}</p>
          <p>Tax: {orderDetails.o_tax}</p>
          <p>Final Price: {orderDetails.o_final_price}</p>
        </Col>
      </Row>
    </div>
  );
}

export default PlaceOrder;
