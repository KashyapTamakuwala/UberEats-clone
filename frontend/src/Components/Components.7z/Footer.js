import React from 'react'

function Footer() {
    return (
        <div style={{marginTop: "5%", backgroundColor: "black", color: "white", height: "50px"}}>
            <h5> @copyrights reserved</h5>
        </div>
    )
}

export default Footer
